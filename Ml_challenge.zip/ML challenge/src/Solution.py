import pandas as pd
import numpy as np
import re
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
import requests
import os

class ProductPricePredictor:
    def __init__(self):
        self.unit_encoder = LabelEncoder()
        self.model = None
        self.feature_columns = []
        self.fitted_units = set()
        
    def extract_features(self, catalog_content):
        """Extract structured features from catalog content"""
        features = {}
        
        # 1. Extract Value and Unit (MOST IMPORTANT)
        value_match = re.search(r'Value:\s*([\d.]+)', catalog_content)
        unit_match = re.search(r'Unit:\s*([^\n]+)', catalog_content)
        
        features['value'] = float(value_match.group(1)) if value_match else 1.0
        raw_unit = unit_match.group(1).strip().lower() if unit_match else 'count'
        
        # Clean and standardize units
        features['unit'] = self.clean_unit(raw_unit)
        
        # 2. Extract text-based features
        text_lower = catalog_content.lower()
        
        # Product category detection
        features['is_food'] = int(any(word in text_lower for word in 
                                   ['chutney', 'sauce', 'candy', 'tea', 'coffee', 'spice', 'snack', 
                                    'chocolate', 'cookie', 'biscuit', 'cereal', 'pasta', 'rice']))
        features['is_beverage'] = int(any(word in text_lower for word in 
                                       ['tea', 'coffee', 'juice', 'drink', 'beverage', 'soda', 'water']))
        features['is_seasoning'] = int(any(word in text_lower for word in 
                                        ['spice', 'seasoning', 'extract', 'flavor', 'herb', 'salt']))
        features['is_health'] = int(any(word in text_lower for word in 
                                      ['vitamin', 'supplement', 'protein', 'organic', 'natural']))
        
        # Text length features
        features['text_length'] = len(catalog_content)
        features['word_count'] = len(catalog_content.split())
        
        # Premium indicators
        features['has_organic'] = int('organic' in text_lower)
        features['has_premium'] = int(any(word in text_lower for word in 
                                        ['premium', 'gourmet', 'artisan', 'handcrafted', 'luxury']))
        
        # Quantity indicators
        features['is_bulk'] = int(any(word in text_lower for word in 
                                    ['bulk', 'pack', 'case', 'multipack', 'value pack']))
        
        return features
    
    def clean_unit(self, unit):
        """Clean and standardize unit labels"""
        unit = str(unit).lower().strip()
        
        # Standardize common units
        if any(u in unit for u in ['ounce', 'oz']):
            return 'ounce'
        elif any(u in unit for u in ['fl oz', 'fluid ounce']):
            return 'fl oz'
        elif any(u in unit for u in ['count', 'ct', 'piece', 'pack']):
            return 'count'
        elif any(u in unit for u in ['pound', 'lb']):
            return 'pound'
        elif any(u in unit for u in ['gram', 'g ']):
            return 'gram'
        elif any(u in unit for u in ['kg', 'kilogram']):
            return 'kilogram'
        elif any(u in unit for u in ['liter', 'litre', 'l ']):
            return 'liter'
        elif any(u in unit for u in ['ml', 'milliliter']):
            return 'milliliter'
        elif any(u in unit for u in ['capsule', 'tablet', 'pill']):
            return 'capsule'
        else:
            return 'other'
    
    def download_image_features(self, image_url):
        """Extract basic image features"""
        try:
            return {
                'image_exists': 1,
                'has_product_image': int('images/i/' in image_url.lower())
            }
        except:
            return {'image_exists': 0, 'has_product_image': 0}
    
    def prepare_features(self, df, is_training=True):
        """Prepare features for training/prediction"""
        features_list = []
        
        for idx, row in df.iterrows():
            # Extract text features
            text_features = self.extract_features(row['catalog_content'])
            
            # Extract image features
            image_features = self.download_image_features(row['image_link'])
            
            # Combine all features
            combined_features = {**text_features, **image_features}
            features_list.append(combined_features)
        
        # Convert to DataFrame
        features_df = pd.DataFrame(features_list)
        
        # Handle unit encoding
        if 'unit' in features_df.columns:
            if is_training:
                # Fit and transform for training
                features_df['unit_encoded'] = self.unit_encoder.fit_transform(features_df['unit'])
                self.fitted_units = set(self.unit_encoder.classes_)
            else:
                # Transform for test data - handle unseen units
                features_df['unit_encoded'] = features_df['unit'].apply(
                    lambda x: self.unit_encoder.transform([x])[0] 
                    if x in self.fitted_units 
                    else -1  # Use -1 for unseen units
                )
        
        # Select final feature columns
        feature_cols = ['value', 'unit_encoded', 'is_food', 'is_beverage', 
                       'is_seasoning', 'is_health', 'text_length', 'word_count', 
                       'has_organic', 'has_premium', 'is_bulk',
                       'image_exists', 'has_product_image']
        
        self.feature_columns = [col for col in feature_cols if col in features_df.columns]
        
        # Fill any missing values
        features_df = features_df[self.feature_columns].fillna(0)
        
        return features_df
    
    def train(self, train_df):
        """Train the model"""
        print("Extracting features from training data...")
        X = self.prepare_features(train_df, is_training=True)
        y = train_df['price'].values
        
        print(f"Training on {len(X)} samples with {len(self.feature_columns)} features")
        print(f"Unique units found: {len(self.fitted_units)}")
        
        # Train Random Forest model
        self.model = RandomForestRegressor(
            n_estimators=100,
            max_depth=20,
            min_samples_split=10,
            random_state=42,
            n_jobs=-1
        )
        
        self.model.fit(X, y)
        print("Model training completed!")
        
        # Show feature importance
        feature_importance = pd.DataFrame({
            'feature': self.feature_columns,
            'importance': self.model.feature_importances_
        }).sort_values('importance', ascending=False)
        
        print("\nTop 10 Feature Importances:")
        print(feature_importance.head(10))
    
    def predict(self, test_df):
        """Make predictions on test data"""
        if self.model is None:
            raise ValueError("Model not trained yet!")
        
        print("Extracting features from test data...")
        X_test = self.prepare_features(test_df, is_training=False)
        
        print("Making predictions...")
        predictions = self.model.predict(X_test)
        
        # Ensure positive prices and reasonable range
        predictions = np.maximum(predictions, 0.1)
        predictions = np.minimum(predictions, 1000)  # Cap at $1000
        
        return predictions

def main():
    # Initialize predictor
    predictor = ProductPricePredictor()
    
    try:
        # Load training data
        print("Loading training data...")
        train_df = pd.read_csv('dataset/train.csv')
        print(f"Training data loaded: {len(train_df)} samples")
        
        # Train model
        predictor.train(train_df)
        
        # Load test data
        print("\nLoading test data...")
        test_df = pd.read_csv('dataset/test.csv')
        print(f"Test data loaded: {len(test_df)} samples")
        
        # Make predictions
        predictions = predictor.predict(test_df)
        
        # Create submission file
        submission_df = pd.DataFrame({
            'sample_id': test_df['sample_id'],
            'price': predictions
        })
        
        # Save predictions
        submission_df.to_csv('Submission/test_out.csv', index=False)
        print("\n✅ Predictions saved to test_out.csv")
        
        # Show statistics
        print(f"\n Prediction Statistics:")
        print(f"Min price: ${predictions.min():.2f}")
        print(f"Max price: ${predictions.max():.2f}")
        print(f"Mean price: ${predictions.mean():.2f}")
        print(f"Median price: ${np.median(predictions):.2f}")
        print(f"Total predictions: {len(predictions)}")
        
    except Exception as e:
        print(f" Error: {e}")
        # Create dummy submission file as fallback
        test_df = pd.read_csv('dataset/test.csv')
        submission_df = pd.DataFrame({
            'sample_id': test_df['sample_id'],
            'price': np.random.uniform(5, 100, len(test_df))
        })
        submission_df.to_csv('Submission/test_out.csv', index=False)
        print("  Created fallback predictions due to error")

if __name__ == "__main__":
    main()